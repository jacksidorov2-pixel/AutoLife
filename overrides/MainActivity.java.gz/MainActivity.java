package com.autolife;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.UsbAccessory;
import android.hardware.usb.UsbManager;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;

import com.autolife.core.UsbCarLifeTransport;

public class MainActivity extends Activity {
    private static final int RC_SCREEN_CAPTURE = 5001;
    private static final int RC_AUDIO = 5002;
    private static final String ACTION_USB_PERMISSION = "com.autolife.USB_PERMISSION";

    private UsbManager usbManager;
    private UsbCarLifeTransport transport;
    private TextView statusView;
    private TextView touchView;
    private TextView traceView;
    private boolean captureRequestPending;
    private boolean projectionWantedAfterAudio;

    private final UsbCarLifeTransport.Listener transportListener = new UsbCarLifeTransport.Listener() {
        @Override
        public void onStatus(String status) {
            runOnUiThread(() -> setStatus(status));
        }

        @Override
        public void onTrace(String line) {
            runOnUiThread(() -> refreshTrace());
        }

        @Override
        public void onVideoConfig(int width, int height, int fps) {
            runOnUiThread(() -> setStatus("Mazda запросила " + width + " × " + height + " @ " + fps + " fps"));
        }

        @Override
        public void onProjectionRequested() {
            runOnUiThread(() -> beginProjection());
        }

        @Override
        public void onHardKey(int keyCode) {
            runOnUiThread(() -> setStatus("CarLife hard key: " + keyCode + " (mapping добавим после теста Mazda)"));
        }
    };

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                UsbAccessory accessory = getAccessory(intent);
                boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                if (granted && accessory != null) {
                    transport.connect(accessory);
                } else {
                    setStatus("USB-разрешение для CarLife не выдано");
                }
            } else if (UsbManager.ACTION_USB_ACCESSORY_ATTACHED.equals(action)) {
                UsbAccessory accessory = getAccessory(intent);
                connectAccessory(accessory);
            } else if (UsbManager.ACTION_USB_ACCESSORY_DETACHED.equals(action)) {
                transport.close();
                setStatus("CarLife USB отключён");
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setStatusBarColor(Color.BLACK);
            getWindow().setNavigationBarColor(Color.BLACK);
        }

        usbManager = (UsbManager) getSystemService(USB_SERVICE);
        transport = ((AutoLifeApp) getApplication()).getTransport();
        transport.addListener(transportListener);
        buildUi();
        refreshTrace();
        registerUsbReceiver();

        UsbAccessory accessory = getAccessory(getIntent());
        if (accessory != null) connectAccessory(accessory);
        else connectFirstAccessory();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        UsbAccessory accessory = getAccessory(intent);
        if (accessory != null) connectAccessory(accessory);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTouchStatus();
    }

    @Override
    protected void onDestroy() {
        transport.removeListener(transportListener);
        try { unregisterReceiver(usbReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(32), dp(22), dp(32), dp(22));
        root.setBackgroundColor(Color.rgb(18, 20, 24));

        TextView title = new TextView(this);
        title.setText("AutoLife");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setGravity(Gravity.START);
        root.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView subtitle = new TextView(this);
        subtitle.setText("Android Auto-like интерфейс поверх штатного Baidu CarLife");
        subtitle.setTextColor(Color.rgb(170, 178, 190));
        subtitle.setTextSize(15);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subtitleLp.topMargin = dp(4);
        root.addView(subtitle, subtitleLp);

        statusView = new TextView(this);
        statusView.setText("CarLife: ожидание USB");
        statusView.setTextColor(Color.rgb(205, 220, 255));
        statusView.setTextSize(16);
        statusView.setPadding(dp(18), dp(14), dp(18), dp(14));
        statusView.setBackground(rounded(Color.rgb(35, 42, 55), 18));
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        statusLp.topMargin = dp(18);
        root.addView(statusView, statusLp);

        LinearLayout apps = new LinearLayout(this);
        apps.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams appsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        appsLp.topMargin = dp(20);
        root.addView(apps, appsLp);

        Button map = bigButton("🗺  2ГИС");
        map.setOnClickListener(v -> launchPackage("ru.dublgis.dgismobile", "2ГИС"));
        apps.addView(map, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        Space gap = new Space(this);
        apps.addView(gap, new LinearLayout.LayoutParams(dp(16), 1));

        Button music = bigButton("♫  Яндекс Музыка");
        music.setOnClickListener(v -> launchPackage("ru.yandex.music", "Яндекс Музыка"));
        apps.addView(music, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams controlsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        controlsLp.topMargin = dp(18);
        root.addView(controls, controlsLp);

        Button usb = smallButton("USB CarLife");
        usb.setOnClickListener(v -> connectFirstAccessory());
        controls.addView(usb, new LinearLayout.LayoutParams(0, dp(52), 1f));

        Space c1 = new Space(this);
        controls.addView(c1, new LinearLayout.LayoutParams(dp(10), 1));

        Button capture = smallButton("Проекция экрана");
        capture.setOnClickListener(v -> beginProjection());
        controls.addView(capture, new LinearLayout.LayoutParams(0, dp(52), 1f));

        Space c2 = new Space(this);
        controls.addView(c2, new LinearLayout.LayoutParams(dp(10), 1));

        Button accessibility = smallButton("Touch-доступ");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        controls.addView(accessibility, new LinearLayout.LayoutParams(0, dp(52), 1f));

        touchView = new TextView(this);
        touchView.setTextSize(13);
        touchView.setTextColor(Color.rgb(150, 160, 172));
        LinearLayout.LayoutParams touchLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        touchLp.topMargin = dp(10);
        root.addView(touchView, touchLp);

        TextView logTitle = new TextView(this);
        logTitle.setText("Диагностика CarLife handshake");
        logTitle.setTextColor(Color.WHITE);
        logTitle.setTextSize(14);
        LinearLayout.LayoutParams logTitleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        logTitleLp.topMargin = dp(8);
        root.addView(logTitle, logTitleLp);

        ScrollView logScroll = new ScrollView(this);
        traceView = new TextView(this);
        traceView.setTextColor(Color.rgb(175, 205, 180));
        traceView.setTextSize(11);
        traceView.setTextIsSelectable(true);
        traceView.setPadding(dp(12), dp(8), dp(12), dp(8));
        traceView.setBackground(rounded(Color.rgb(15, 28, 20), 12));
        logScroll.addView(traceView, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams logLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(110));
        logLp.topMargin = dp(5);
        root.addView(logScroll, logLp);

        LinearLayout logButtons = new LinearLayout(this);
        logButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button copyLog = smallButton("Копировать лог");
        copyLog.setOnClickListener(v -> copyTrace());
        logButtons.addView(copyLog, new LinearLayout.LayoutParams(0, dp(44), 1f));
        Space logGap = new Space(this);
        logButtons.addView(logGap, new LinearLayout.LayoutParams(dp(10), 1));
        Button clearLog = smallButton("Очистить лог");
        clearLog.setOnClickListener(v -> { transport.clearTrace(); refreshTrace(); });
        logButtons.addView(clearLog, new LinearLayout.LayoutParams(0, dp(44), 1f));
        LinearLayout.LayoutParams logButtonsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        logButtonsLp.topMargin = dp(5);
        root.addView(logButtons, logButtonsLp);

        setContentView(root);
        refreshTouchStatus();
    }

    private Button bigButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(24);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(Color.rgb(42, 48, 60), 28));
        return b;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(rounded(Color.rgb(48, 56, 70), 18));
        return b;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private void connectFirstAccessory() {
        UsbAccessory[] list = usbManager.getAccessoryList();
        if (list == null || list.length == 0) {
            setStatus("CarLife accessory пока не появился. Открой CarLife на Mazda и подключи USB.");
            return;
        }
        connectAccessory(list[0]);
    }

    private void connectAccessory(UsbAccessory accessory) {
        if (accessory == null) return;
        if (transport.isConnected()) {
            setStatus("CarLife USB уже подключён — повторное открытие пропущено");
            return;
        }
        if (usbManager.hasPermission(accessory)) {
            transport.connect(accessory);
            return;
        }
        Intent permissionIntent = new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName());
        PendingIntent pi = PendingIntent.getBroadcast(
                this,
                0,
                permissionIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE
        );
        usbManager.requestPermission(accessory, pi);
        setStatus("Запрошено USB-разрешение для CarLife");
    }

    private void beginProjection() {
        if (captureRequestPending) return;
        if (!transport.isConnected()) {
            setStatus("Сначала подключаем Mazda через CarLife USB");
            connectFirstAccessory();
            return;
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            projectionWantedAfterAudio = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, RC_AUDIO);
            return;
        }
        requestScreenCapture();
    }

    private void requestScreenCapture() {
        captureRequestPending = true;
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent consent;
        if (Build.VERSION.SDK_INT >= 34) {
            // We need the entire display so AutoLife can switch between 2GIS and Yandex Music.
            consent = manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
        } else {
            consent = manager.createScreenCaptureIntent();
        }
        startActivityForResult(consent, RC_SCREEN_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != RC_SCREEN_CAPTURE) return;
        captureRequestPending = false;
        if (resultCode != RESULT_OK || data == null) {
            setStatus("Разрешение на проекцию экрана отменено");
            return;
        }

        Intent service = new Intent(this, ProjectionService.class)
                .setAction(ProjectionService.ACTION_START)
                .putExtra(ProjectionService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ProjectionService.EXTRA_RESULT_DATA, data)
                .putExtra(ProjectionService.EXTRA_WIDTH, transport.getHuWidth())
                .putExtra(ProjectionService.EXTRA_HEIGHT, transport.getHuHeight())
                .putExtra(ProjectionService.EXTRA_FPS, transport.getHuFps());
        startForegroundService(service);
        setStatus("Проекция запущена → CarLife " + transport.getHuWidth() + " × " + transport.getHuHeight());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RC_AUDIO && projectionWantedAfterAudio) {
            projectionWantedAfterAudio = false;
            requestScreenCapture();
        }
    }

    private void launchPackage(String packageName, String title) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch == null) {
            setStatus(title + " не установлен на телефоне");
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(launch);
    }

    private void registerUsbReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_ACCESSORY_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(usbReceiver, filter);
        }
    }

    @SuppressWarnings("deprecation")
    private static UsbAccessory getAccessory(Intent intent) {
        if (intent == null) return null;
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY, UsbAccessory.class);
        }
        return intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY);
    }

    private void refreshTouchStatus() {
        if (touchView == null) return;
        touchView.setText(AutoLifeAccessibilityService.isReady()
                ? "✓ Touch bridge активен — нажатия Mazda будут передаваться телефону"
                : "⚠ Для управления с экрана Mazda включи AutoLife в специальных возможностях Android");
    }

    private void setStatus(String text) {
        if (statusView != null) statusView.setText(text);
        refreshTrace();
    }

    private void refreshTrace() {
        if (traceView != null) traceView.setText(transport.getTraceSnapshot());
    }

    private void copyTrace() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        String log = transport.getTraceSnapshot();
        clipboard.setPrimaryClip(ClipData.newPlainText("AutoLife CarLife log", log));
        setStatus("Диагностический лог скопирован");
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
