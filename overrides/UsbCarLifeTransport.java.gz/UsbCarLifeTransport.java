package com.autolife.core;

import android.hardware.usb.UsbAccessory;
import android.hardware.usb.UsbManager;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

public final class UsbCarLifeTransport {
    private static final String TAG = "AutoLife";

    public static final int CHANNEL_CMD = 1;
    public static final int CHANNEL_VIDEO = 2;
    public static final int CHANNEL_MEDIA = 3;
    public static final int CHANNEL_TOUCH = 6;

    public static final int MSG_CMD_HU_PROTOCOL_VERSION = 0x00018001;
    public static final int MSG_CMD_PROTOCOL_VERSION_MATCH_STATUS = 0x00010002;
    public static final int MSG_CMD_HU_INFO = 0x00018003;
    public static final int MSG_CMD_MD_INFO = 0x00010004;
    public static final int MSG_CMD_VIDEO_ENCODER_INIT = 0x00018007;
    public static final int MSG_CMD_VIDEO_ENCODER_INIT_DONE = 0x00010008;
    public static final int MSG_CMD_VIDEO_ENCODER_START = 0x00018009;
    public static final int MSG_CMD_FOREGROUND = 0x0001001B;
    public static final int MSG_CMD_STATISTIC_INFO = 0x00018027;
    public static final int MSG_CMD_MD_AUTHEN_RESULT = 0x0001004B;

    public static final int MSG_VIDEO_DATA = 0x00020001;
    public static final int MSG_MEDIA_INIT = 0x00030001;
    public static final int MSG_MEDIA_DATA = 0x00030006;
    public static final int MSG_TOUCH_ACTION = 0x00068001;
    public static final int MSG_TOUCH_CAR_HARD_KEY_CODE = 0x00068008;

    public interface Listener {
        default void onStatus(String status) {}
        default void onTrace(String line) {}
        default void onVideoConfig(int width, int height, int fps) {}
        default void onProjectionRequested() {}
        default void onHardKey(int keyCode) {}
    }

    public interface TouchSink {
        void onTouch(int action, int x, int y, int huWidth, int huHeight);
    }

    private final UsbManager usbManager;
    private final List<Listener> listeners = new CopyOnWriteArrayList<>();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final Object writeLock = new Object();
    private final Object traceLock = new Object();
    private final ArrayDeque<String> traceLines = new ArrayDeque<>();
    private static final int MAX_TRACE_LINES = 60;

    private volatile TouchSink touchSink;
    private volatile ParcelFileDescriptor pfd;
    private volatile FileInputStream input;
    private volatile FileOutputStream output;
    private volatile Thread readThread;
    private volatile int huWidth = 1280;
    private volatile int huHeight = 720;
    private volatile int huFps = 30;

    public UsbCarLifeTransport(UsbManager usbManager) {
        this.usbManager = usbManager;
    }

    public void addListener(Listener listener) {
        if (listener != null) listeners.add(listener);
    }

    public void removeListener(Listener listener) {
        listeners.remove(listener);
    }

    public void setTouchSink(TouchSink touchSink) {
        this.touchSink = touchSink;
    }

    public boolean isConnected() {
        return running.get();
    }

    public int getHuWidth() { return huWidth; }
    public int getHuHeight() { return huHeight; }
    public int getHuFps() { return huFps; }

    public String getTraceSnapshot() {
        synchronized (traceLock) {
            StringBuilder out = new StringBuilder();
            for (String line : traceLines) {
                if (out.length() > 0) out.append('\n');
                out.append(line);
            }
            return out.toString();
        }
    }

    public void clearTrace() {
        synchronized (traceLock) {
            traceLines.clear();
        }
        trace("--- log cleared ---");
    }

    public synchronized boolean connect(UsbAccessory accessory) {
        if (running.get() && pfd != null) {
            trace("USB connect ignored: already connected");
            return true;
        }
        close();
        if (accessory == null) {
            status("CarLife accessory не найден");
            return false;
        }
        try {
            trace("USB accessory: " + safe(accessory.getManufacturer())
                    + " / " + safe(accessory.getModel())
                    + " / v" + safe(accessory.getVersion())
                    + ", permission=" + usbManager.hasPermission(accessory));
            pfd = usbManager.openAccessory(accessory);
            if (pfd == null) {
                status("Нет разрешения на USB accessory");
                return false;
            }
            input = new FileInputStream(pfd.getFileDescriptor());
            output = new FileOutputStream(pfd.getFileDescriptor());
            running.set(true);
            trace("USB OPEN OK; waiting HU packet");
            readThread = new Thread(this::readLoop, "AutoLife-CarLife-USB");
            readThread.start();
            status("CarLife USB подключён: " + accessory.getManufacturer() + " / " + accessory.getModel());
            return true;
        } catch (Exception e) {
            Log.e(TAG, "USB accessory open failed", e);
            status("Ошибка USB: " + e.getMessage());
            close();
            return false;
        }
    }

    public synchronized void close() {
        running.set(false);
        Thread t = readThread;
        readThread = null;
        if (t != null) t.interrupt();
        try { if (input != null) input.close(); } catch (Exception ignored) {}
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
        input = null;
        output = null;
        pfd = null;
    }

    public void sendVideoFrame(byte[] h264) {
        if (h264 == null || h264.length == 0 || !running.get()) return;
        send(CHANNEL_VIDEO, CarLifeWire.streamMessage(MSG_VIDEO_DATA, h264));
    }

    public void sendAudioPcm(byte[] pcm, int length) {
        if (pcm == null || length <= 0 || !running.get()) return;
        byte[] slice;
        if (length == pcm.length) {
            slice = pcm;
        } else {
            slice = new byte[length];
            System.arraycopy(pcm, 0, slice, 0, length);
        }
        send(CHANNEL_MEDIA, CarLifeWire.streamMessage(MSG_MEDIA_DATA, slice));
    }

    private void readLoop() {
        try {
            while (running.get()) {
                byte[] outer = new byte[8];
                CarLifeWire.readFully(input, outer);
                int channel = outer[3] & 0xff;
                int innerLength = CarLifeWire.getIntBE(outer, 4);
                trace("RX outer ch=" + channel + " len=" + innerLength);
                if (innerLength < 8 || innerLength > 16 * 1024 * 1024) {
                    throw new IOException("Invalid CarLife packet length: " + innerLength);
                }
                byte[] inner = new byte[innerLength];
                CarLifeWire.readFully(input, inner);
                handlePacket(channel, inner);
            }
        } catch (Exception e) {
            if (running.get()) {
                Log.e(TAG, "CarLife USB read loop stopped", e);
                status("CarLife отключён: " + e.getMessage());
            }
        } finally {
            close();
        }
    }

    private void handlePacket(int channel, byte[] inner) {
        if (channel != CHANNEL_CMD && channel != CHANNEL_TOUCH) return;
        if (inner.length < 8) return;

        int declared = CarLifeWire.getU16BE(inner, 0);
        int serviceId = CarLifeWire.getIntBE(inner, 4);
        int available = inner.length - 8;
        int dataLength = Math.min(declared, available);
        byte[] payload = new byte[dataLength];
        if (dataLength > 0) System.arraycopy(inner, 8, payload, 0, dataLength);

        String rx = String.format("RX ch=%d service=0x%08X len=%d", channel, serviceId, dataLength);
        Log.d(TAG, rx);
        trace(rx);

        if (channel == CHANNEL_CMD) {
            handleCommand(serviceId, payload);
        } else {
            handleTouch(serviceId, payload);
        }
    }

    private void handleCommand(int serviceId, byte[] payload) {
        switch (serviceId) {
            case MSG_CMD_HU_PROTOCOL_VERSION -> {
                trace("STEP 1/5 HU_PROTOCOL_VERSION");
                sendCommand(MSG_CMD_PROTOCOL_VERSION_MATCH_STATUS, ProtoLite.int32(1, 1));
                status("CarLife: protocol match OK");
            }
            case MSG_CMD_HU_INFO -> {
                trace("STEP 2/5 HU_INFO");
                sendCommand(MSG_CMD_MD_INFO, buildDeviceInfo());
                status("CarLife: HU info получено");
            }
            case MSG_CMD_VIDEO_ENCODER_INIT -> {
                trace("STEP 3/5 VIDEO_ENCODER_INIT");
                int width = ProtoLite.getInt32(payload, 1, huWidth);
                int height = ProtoLite.getInt32(payload, 2, huHeight);
                int fps = ProtoLite.getInt32(payload, 3, huFps);
                if (width >= 320 && width <= 4096) huWidth = width;
                if (height >= 240 && height <= 2160) huHeight = height;
                if (fps >= 10 && fps <= 60) huFps = fps;

                // CarLife expects the init payload echoed back in INIT_DONE.
                sendCommand(MSG_CMD_VIDEO_ENCODER_INIT_DONE, payload);
                sendCommand(MSG_CMD_FOREGROUND, new byte[0]);
                status("CarLife video: " + huWidth + "x" + huHeight + " @ " + huFps + " fps");
                for (Listener l : listeners) l.onVideoConfig(huWidth, huHeight, huFps);
            }
            case MSG_CMD_VIDEO_ENCODER_START -> {
                trace("STEP 4/5 VIDEO_ENCODER_START");
                sendMediaInit();
                status("CarLife запросил запуск проекции");
                for (Listener l : listeners) l.onProjectionRequested();
            }
            case MSG_CMD_STATISTIC_INFO -> {
                trace("STEP 5/5 STATISTIC_INFO -> AUTH OK");
                sendCommand(MSG_CMD_MD_AUTHEN_RESULT, ProtoLite.bool(1, true));
                status("CarLife authentication OK");
            }
            default -> {
                String unhandled = String.format("UNHANDLED CMD 0x%08X len=%d", serviceId, payload.length);
                Log.d(TAG, unhandled);
                trace(unhandled);
            }
        }
    }

    private void handleTouch(int serviceId, byte[] payload) {
        if (serviceId == MSG_TOUCH_ACTION) {
            int action = ProtoLite.getInt32(payload, 1, -1);
            int x = ProtoLite.getInt32(payload, 2, -1);
            int y = ProtoLite.getInt32(payload, 3, -1);
            TouchSink sink = touchSink;
            if (sink != null && action >= 0 && x >= 0 && y >= 0) {
                sink.onTouch(action, x, y, huWidth, huHeight);
            }
        } else if (serviceId == MSG_TOUCH_CAR_HARD_KEY_CODE) {
            int key = ProtoLite.getInt32(payload, 1, -1);
            for (Listener l : listeners) l.onHardKey(key);
        }
    }

    private byte[] buildDeviceInfo() {
        // Legacy-compatible identity used by known CarLife projection implementations.
        // IMPORTANT: field 22 is CarLife's authentication token; never put our app name there.
        // Leaving token absent is intentional.
        return new ProtoLite.Writer()
                .string(1, "Android")
                .string(2, "sdm845")
                .string(11, "c4-miui-ota-bd47.bj")
                .string(12, "QKQ1.190828.002")
                .string(16, "unknown")
                .string(19, "10")
                .string(20, "29")
                .int32(21, 29)
                .toByteArray();
    }

    private void sendMediaInit() {
        byte[] payload = new ProtoLite.Writer()
                .int32(1, 48000)
                .int32(2, 2)
                .int32(3, 16)
                .toByteArray();
        send(CHANNEL_MEDIA, CarLifeWire.streamMessage(MSG_MEDIA_INIT, payload));
    }

    private void sendCommand(int serviceId, byte[] payload) {
        byte[] p = payload == null ? new byte[0] : payload;
        trace(String.format("TX CMD service=0x%08X len=%d", serviceId, p.length));
        send(CHANNEL_CMD, CarLifeWire.commandMessage(serviceId, p));
    }

    private void send(int channel, byte[] inner) {
        FileOutputStream out = output;
        if (!running.get() || out == null) return;
        byte[] packet = CarLifeWire.packet(channel, inner);
        synchronized (writeLock) {
            try {
                out.write(packet);
                out.flush();
            } catch (IOException e) {
                Log.e(TAG, "USB write failed", e);
                status("Ошибка записи USB: " + e.getMessage());
                close();
            }
        }
    }

    private void status(String text) {
        Log.i(TAG, text);
        trace("STATUS " + text);
        for (Listener l : listeners) l.onStatus(text);
    }

    private void trace(String text) {
        String line = String.format("%05d %s", android.os.SystemClock.elapsedRealtime() % 100000, text);
        synchronized (traceLock) {
            traceLines.addLast(line);
            while (traceLines.size() > MAX_TRACE_LINES) traceLines.removeFirst();
        }
        Log.d(TAG, line);
        for (Listener l : listeners) l.onTrace(line);
    }

    private static String safe(String value) {
        return value == null ? "?" : value;
    }
}
